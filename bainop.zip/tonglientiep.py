n=int(input())
def test(n):
    if n%3==0:
           return "có"
    return "không"
print(test(n))