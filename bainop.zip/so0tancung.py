n=int(input())
s=1
for i in range(1,n+1):
    s*=i
t=0
while s%10==0:
    t+=1
    s=s/10
print(t)