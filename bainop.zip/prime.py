n=int(input())

s=[]
for i in range(2,n+1):
    while n%i==0:
        s.append(str(i))
        n=n/i
d="x".join(s)
         
print(d)        