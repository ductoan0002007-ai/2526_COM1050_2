a,b,c=map(int,input().split())
def testtriangle(a,b,c):
    if a+b-c>0 and b+c-a>0 and c+a-b>0:
        if a==b==c :
            return "tam giác đều"
        elif a**2==b**2+c**2 or b**2==a**2+c**2 or c**2==a**2+b**2:
            return "tam giác vuông"
        elif (a==b!=c) or (a==c!=b) or (b==c!=a):
            return "tam giác cân"
        else:
            return "tam giác thường "
    return "không phải tam giác "
print(testtriangle(a,b,c))

           